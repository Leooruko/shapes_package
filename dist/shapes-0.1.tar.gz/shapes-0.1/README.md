# Shapes package
this package is a representation of shapes with dimensions and various methods that can be applied to each ranging from calculating the area, perimeter , matching shapes based on dimensions

# How to Install
run..
pip install shapes 